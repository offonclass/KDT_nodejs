const { User, Profile } = require("../models");
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')



const signup = async (req, res) => {
    try {
        console.log('req!!', req.body);
        const { userId, pw, username, age, email } = req.body;
        const findId = await User.findOne({ where: { userId } })
        const findEmail = await Profile.findOne({ where: { email } })
        if (findId) {
            res.json({ result: false, message: '아이디 중복' })
        } else if (findEmail) {
            res.json({ result: false, message: '이메일 중복' })
        } else {
            const sign = bcrypt.hashSync(pw, 10)
            await User.create({ userId, password: sign })
            await Profile.create({ username, age, email })
            res.json({ result: true, message: '회원가입 성공' })
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ result: false, message: '서버오류' })
    }
}



const login = async (req, res) => {
    try {
        console.log('req!!', req.body);
        const { userId, pw } = req.body;
        const find = await User.findOne({ where: { userId } })
        const compare = bcrypt.compareSync(pw, find.password)
        console.log('compare!!', compare);
        if(compare) {
            const findProfile = await Profile.findOnd({ where: {userId: find.id}})
            console.log('findProfile!!', findProfile);
            res.json()
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ result: false, message: '서버오류' })
    }

}

module.exports = { signup, login }